package com.example.trackingpro

import android.Manifest
import android.app.*
import android.content.Intent
import android.content.pm.PackageManager
import android.location.Location
import android.net.Uri
import android.os.IBinder
import android.provider.Settings
import androidx.core.app.ActivityCompat
import androidx.core.app.NotificationCompat
import com.google.android.gms.location.*

class LocationService : Service() {

    private lateinit var fusedClient: FusedLocationProviderClient

    override fun onCreate() {
        super.onCreate()
        fusedClient = LocationServices.getFusedLocationProviderClient(this)

        val channel = NotificationChannel(
            "track",
            "Tracking Service",
            NotificationManager.IMPORTANCE_LOW
        )
        getSystemService(NotificationManager::class.java).createNotificationChannel(channel)

        val notification = NotificationCompat.Builder(this, "track")
            .setContentTitle("Tracking aktif")
            .setContentText("Melacak lokasi HP")
            .setSmallIcon(android.R.drawable.ic_menu_mylocation)
            .build()

        startForeground(1, notification)

        requestLocation()
    }

    private fun requestLocation() {
        if (ActivityCompat.checkSelfPermission(
                this, Manifest.permission.ACCESS_FINE_LOCATION
            ) != PackageManager.PERMISSION_GRANTED
        ) return

        fusedClient.lastLocation.addOnSuccessListener { loc: Location? ->
            loc?.let { sendEmail(it.latitude, it.longitude) }
        }
    }

    private fun sendEmail(lat: Double, lon: Double) {
        val androidId = Settings.Secure.getString(
            contentResolver, Settings.Secure.ANDROID_ID
        )

        val body = "Lokasi: $lat,$lon\nAndroidID: $androidId\nhttps://maps.google.com/?q=$lat,$lon"

        val intent = Intent(Intent.ACTION_SENDTO).apply {
            data = Uri.parse("mailto:emailtujuan@gmail.com")
            putExtra(Intent.EXTRA_SUBJECT, "Tracking Otomatis")
            putExtra(Intent.EXTRA_TEXT, body)
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        startActivity(intent)
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
